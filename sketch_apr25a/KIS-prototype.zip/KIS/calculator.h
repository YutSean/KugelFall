#include "Arduino.h"

class calculator {
  public:
    calculator();
    void  startTime();
    void  endTime();
    double angleSpeed();
    int predict();

  private:
    bool pos;
    int sTime;
    int eTime
    double aSpeed;
    double beschleunigung;
};
