#include "calculator.h"
#define FALL_ZEIT 404

calculator::calculator() {
    aSpeed = 0;
    beschleunigung = 0;
    position = 0;
}

void calculator::startTime() {
    sTime = millis();
}

void calculator::endTime() {
    eTime = millis();
}

void calculator::angleSpeed() {
    if (sTime > eTime) {

    }
    if (sTime < eTime) {
        int t = (eTime - sTime) / 1000;
        double temp = aSpeed;
        aSpeed = (1/12) / t;
        if (temp) {
            beschleunigung = (aSpeed - temp) / t;
        }
    }
}

int calculator::predict(bool pos) {
    double avgSpeed = (aSpeed + (FALL_ZEIT * beschleunigung + aSpeed)) / 2;
    double distance = avgSpeed * FALL_ZEIT;
    double abstand = distance - (int)distance;
    int t = (int)(abstand / avgSpeed) * 1000;
    if (pos) {
      t += 0.5 / avgSpeed;
    }
    return t;  
}
