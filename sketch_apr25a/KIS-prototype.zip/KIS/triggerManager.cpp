#include "triggerManager.h"

triggerManager::triggerManager(int trigger_pin) {
    this->tp = trigger_pin;
    dropped = false;
}

bool triggerManager::sendSignal() {
    if (getTriggerVal() && !dropped) {
        this->dropped = true;
        return true;
    }
    if (dropped && !getTriggerVal()) {
        this->dropped = false;
    }
    return false;
}

bool triggerManager::getTriggerVal() {
    return digitalRead(trigger_pin);
}
